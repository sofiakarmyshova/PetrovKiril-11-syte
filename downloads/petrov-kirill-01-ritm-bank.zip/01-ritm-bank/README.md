# Ритм Банк — Петров Кирилл

[Сайт](https://sofiakarmyshova.github.io/PetrovKiril-11-syte/sites/01-ritm-bank/index.html) · [Исходники](https://github.com/sofiakarmyshova/PetrovKiril-11-syte/tree/main/sites/01-ritm-bank) · [Макет Figma](https://www.figma.com/design/u5F5hNCu7eyUfhZTA8YIiY/Untitled?node-id=0-1)

Запуск: открыть `index.html` или выполнить `python -m http.server 8000` в папке проекта и открыть http://localhost:8000.
