# ИМПУЛЬС — Петров Кирилл

[Сайт](https://sofiakarmyshova.github.io/PetrovKiril-11-syte/sites/08-impulse/index.html) · [Исходники](https://github.com/sofiakarmyshova/PetrovKiril-11-syte/tree/main/sites/08-impulse) · [Макет Figma](https://www.figma.com/design/HySfrOvomqnvmRZJsWHVLq/Untitled?node-id=0-1)

Запуск: открыть `index.html` или выполнить `python -m http.server 8000` в папке проекта и открыть http://localhost:8000.
