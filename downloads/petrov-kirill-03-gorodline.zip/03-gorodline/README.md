# ГородЛайн — Петров Кирилл

[Сайт](https://sofiakarmyshova.github.io/PetrovKiril-11-syte/sites/03-gorodline/index.html) · [Исходники](https://github.com/sofiakarmyshova/PetrovKiril-11-syte/tree/main/sites/03-gorodline) · [Макет Figma](https://www.figma.com/design/fxIRLlRHQ1P1or5Bz0uIV9/Untitled?node-id=0-1)

Запуск: открыть `index.html` или выполнить `python -m http.server 8000` в папке проекта и открыть http://localhost:8000.
