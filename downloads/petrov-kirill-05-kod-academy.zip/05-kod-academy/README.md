# Код Академия — Петров Кирилл

[Сайт](https://sofiakarmyshova.github.io/PetrovKiril-11-syte/sites/05-kod-academy/index.html) · [Исходники](https://github.com/sofiakarmyshova/PetrovKiril-11-syte/tree/main/sites/05-kod-academy) · [Макет Figma](https://www.figma.com/design/KVOCJI7QEmnszRC2WYe0mH/Untitled?node-id=0-1)

Запуск: открыть `index.html` или выполнить `python -m http.server 8000` в папке проекта и открыть http://localhost:8000.
