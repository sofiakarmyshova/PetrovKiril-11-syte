# Тёплый угол — Петров Кирилл

[Сайт](https://sofiakarmyshova.github.io/PetrovKiril-11-syte/sites/02-teply-ugol/index.html) · [Исходники](https://github.com/sofiakarmyshova/PetrovKiril-11-syte/tree/main/sites/02-teply-ugol) · [Макет Figma](https://www.figma.com/design/irxVxS94X7M48gZsLvwRZ5/GPT?t=t4S8dKqmavQwTYJ7-0)

Запуск: открыть `index.html` или выполнить `python -m http.server 8000` в папке проекта и открыть http://localhost:8000.
